﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopStore.Entity.ENUM
{
    public enum DetailType
    {
        stringVal = 1,
        DateVal = 2,
        DateTimeVal = 3,
        intVal = 4,
        decimalVal = 5,
        ListVal = 6,
        Image = 7
    }
}
