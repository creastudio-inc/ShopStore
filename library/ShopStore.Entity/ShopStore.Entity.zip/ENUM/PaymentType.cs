﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopStore.Entity.ENUM
{
    public enum PaymentType
    {
        None = 0,
        Visa = 1,
        MasterCard = 2,
        Mada = 3
    }
}
