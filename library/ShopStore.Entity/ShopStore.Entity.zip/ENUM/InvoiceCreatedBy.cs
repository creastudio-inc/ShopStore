﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopStore.Entity.ENUM
{
    public enum InvoiceCreatedBy
    {
        ByStore = 0,
        ByMobile = 1
    }
}
