﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopStore.Entity.ENUM
{
    public enum ShipmentMethodTypes
    {
        Aramex = 1,
        DHL = 2,
        SMSA = 3,
        CashInDelivery = 4,
        Salasa = 5,
        Manual = 6,
        Root = 7
    }
}
