﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopStore.Entity.ENUM
{
    public enum ArticlesType
    {
        Pages = 0,
        Blog = 1,
        SpecialPage = 3
    }
}
